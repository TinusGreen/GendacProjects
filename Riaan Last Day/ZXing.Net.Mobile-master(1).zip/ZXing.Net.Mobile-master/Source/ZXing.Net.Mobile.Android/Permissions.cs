﻿using Android.App;

[assembly: UsesPermission (Android.Manifest.Permission.Camera)]