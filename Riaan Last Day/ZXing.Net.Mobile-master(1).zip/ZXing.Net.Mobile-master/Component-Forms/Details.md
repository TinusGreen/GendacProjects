ZXing.Net.Mobile for Forms is a C#/.NET library based on the open source Barcode Library: ZXing (Zebra Crossing), using the ZXing.Net Port. It works with Xamarin.iOS, Xamarin.Android, Windows Phone Silverlight, and Windows Universal in Xamarin.Forms apps. 

The goal of ZXing.Net.Mobile is to make scanning barcodes as effortless and painless as possible in your own applications!


## Features

- Xamarin.Forms Page and Views
- Custom Overlays in XAML or C#
- Xamarin.iOS
- Xamarin.Android
- Windows Phone (Silverlight)
- Windows Universal (UAP 10)
